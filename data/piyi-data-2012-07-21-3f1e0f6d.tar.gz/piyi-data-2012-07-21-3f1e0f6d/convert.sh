#!/bin/sh
chw=68
chh=62
mkdir -p imgs
set -x
for ch in ts rd aj pp r fs dh
do
    (
    cd $ch || exit 1
    for f in $ch*.png
    do
        fl=`echo "$f" | sed 's/r\.png/l\.png/'`
        convert -scale ${chw}x${chh} $f ../imgs/$f
        convert -scale ${chw}x${chh} -flop $f ../imgs/$fl
    done
    convert -delay 10 -loop 0 -dispose 2 ../imgs/$ch.r?r.png /tmp/$$.gif
    gifsicle -O3 < /tmp/$$.gif > ../imgs/$ch.ranimr.gif
    convert -delay 10 -loop 0 -dispose 2 ../imgs/$ch.r?l.png /tmp/$$.gif
    gifsicle -O3 < /tmp/$$.gif > ../imgs/$ch.raniml.gif
    )
done

(
cd pp || exit 1
for f in pp*.png
do
    uf=`echo "$f" | sed 's/pp\./pp\.ud\./'`
    ufl=`echo "$uf" | sed 's/r\.png/l\.png/'`
    convert -scale ${chw}x${chh} -flip $f ../imgs/$uf
    convert -scale ${chw}x${chh} -flip -flop $f ../imgs/$ufl
done
)

(
cd icons || exit 1
for f in *.png
do
    wh=`identify "$f" | cut -d' ' -f3`
    w=`echo "$wh" | cut -dx -f1`
    h=`echo "$wh" | cut -dx -f2`
    convert -scale $(( w * 2 ))x$(( h * 2 )) $f ../imgs/$f
done
)

cp text/*.png imgs/
cp cmc/*.png imgs/
convert -scale 210x300 aj/appletree.s0r.png imgs/appletree.s0r.png

(
cd dd || exit 1
for f in dd*.png
do
    fr=`echo "$f" | sed 's/l\.png/r\.png/'`
    cp $f ../imgs/$f
    convert -flop $f ../imgs/$fr
done
)
